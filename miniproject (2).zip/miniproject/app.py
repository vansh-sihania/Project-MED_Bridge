from flask import Flask, render_template, request, redirect, url_for, flash

app = Flask(__name__)
app.secret_key = 'medbridge_secret_key'  # Required for flash messages

@app.route('/')
def home():
    return render_template('project.html')

@app.route('/book-appointment', methods=['POST'])
def book_appointment():
    name = request.form.get('name')
    email = request.form.get('email')
    date = request.form.get('date')
    time = request.form.get('time')
    doctor = request.form.get('DOCTORS')

    # For now, just print or store it in a file
    with open("appointments.txt", "a") as f:
        f.write(f"{name},{email},{date},{time},{doctor}\n")

    flash('Appointment booked successfully!')
    return redirect(url_for('home'))

@app.route('/login', methods=['POST'])
def login():
    user_type = request.form.get('userType')
    username = request.form.get('username')
    password = request.form.get('password')

    # Dummy validation
    if username == 'admin' and password == '1234':
        flash(f'{user_type.capitalize()} login successful!')
    else:
        flash('Invalid credentials. Try again.')

    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)
